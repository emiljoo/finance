<img class="avatar" src="{{ asset($cover)}}" alt="">
