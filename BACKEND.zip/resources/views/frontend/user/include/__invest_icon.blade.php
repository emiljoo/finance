<span class="avatar-img"><img src="{{asset($schema['icon'])}}" alt=""></span>

