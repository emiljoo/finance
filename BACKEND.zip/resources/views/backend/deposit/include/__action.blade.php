@can('deposit-action')
    <span type="button"
          data-id="{{$id}}"
          id="deposit-action"
    ><button class="round-icon-btn red-btn" data-bs-toggle="tooltip" title="" data-bs-original-title="Approval Process"><i
                icon-name="eye"></i></button></span>
    <script>
        'use strict';
        lucide.createIcons();
    </script>
@endcan
