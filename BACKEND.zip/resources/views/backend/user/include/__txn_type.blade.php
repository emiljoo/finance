<div class="site-badge primary-bg">{{ ucwords(str_replace("_"," ",$type)) }}</div>
