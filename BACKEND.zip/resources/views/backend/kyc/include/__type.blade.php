<strong class="transaction">{{ $kyc_type }}</strong>
