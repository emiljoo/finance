<strong> {{ $schema['name'] }} <i icon-name="arrow-big-right"></i> {{ $currencySymbol.$invest_amount }}</strong>
<div class="date">{{ $created_time }}</div>
<script>
  'use strict';
  lucide.createIcons();
</script>
