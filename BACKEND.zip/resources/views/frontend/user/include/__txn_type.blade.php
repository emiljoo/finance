<div class="site-badge primary-bg">{{ ucfirst(str_replace('_',' ',$type)) }}</div>
