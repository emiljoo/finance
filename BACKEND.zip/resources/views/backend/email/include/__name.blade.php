<div class="table-description">
    <div class="icon">
        <i icon-name="mail"></i>
    </div>
    <div class="description">
        <strong>{{ $name }}</strong>
        <div class="date fst-italic">{{ $for }}</div>
    </div>
</div>
<script>
    'use strict';
    lucide.createIcons();
</script>
