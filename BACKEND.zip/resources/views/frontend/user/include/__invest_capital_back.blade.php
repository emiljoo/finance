<div class="site-badge {{ $capital_back ? 'success' : 'warnning' }}">{{ $capital_back ? 'Yes' : 'No' }}</div>

